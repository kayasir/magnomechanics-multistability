# Python source for Part 1

Cross-drive-engineered Kerr multistability in multimagnon cavity magnomechanics

Authors: Kashif Ammar Yasir and Wu-Ming Liu. Source version: 8.0.0.

## Run this paper

This archive is self-contained. Its run_all.py is fixed to Part 1; no paper-selection argument is needed. Shared numerical helper modules are included locally. The equations, numerical settings and solver modules are unchanged from the combined version-8 source release.

Extract the ZIP before running it. The commands below must be run from the extracted Part_I_AU13204_Code_v8 directory, which contains requirements.txt and run_all.py.

Windows, using a Miniforge/conda terminal:

```bat
conda create -n pra-part1 -c conda-forge python=3.12 poppler pip
conda activate pra-part1
python -m pip install -r requirements.txt
python run_all.py --out output
```

Linux/macOS, with Python 3.12 and Poppler installed:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_all.py --out output
```

Poppler supplies pdftops for EPS export. A complete run may take several minutes or longer. The scripts calculate the figures, CSV plotting arrays and JSON diagnostics inside output/. Subsequent runs overwrite generated files in the selected output directory. No external numerical input dataset or proprietary software is required.

## Source files

- run_all.py: runs this paper's figure, validation and control routines.
- model.py: parameter definitions, mean fields, Jacobian, stationary-state reconstruction and linear response.
- algebraic_check.py: polynomial elimination and physical-root verification.
- figures.py and spectra.py: numerical plotting functions and export helpers.
- validate.py: independent root, Jacobian and response checks.
- controls.py: mechanism and limiting-case controls.
- physical_checks.py: dimensional equations and finite omitted-coupling controls.
- submission_checks.py: numerical tolerance, grid and additional physical checks.
- schematic.py: original Figure 1(a) plus the vector technical diagram in Figure 1(b).
- assets/Fig1a_part1.jpg: this paper's original physical illustration; it is not numerical input data.

Set A is parameters(1); set B is parameters(1, True). The source uses the full eight-dimensional cavity–two-magnon–shared-mechanical drift matrix. Production branch sampling uses 10000 linear population points plus near-zero samples. Solid/dashed curves identify stable/unstable stationary states. The yellow-to-brown density scale displays the logarithmic stationary residual; it is not a thermodynamic potential or a stability measure.

All solver rates are dimensionless angular-frequency ratios. Full-precision definitions in the source take precedence over rounded printed tables. Stable states require maximum real drift eigenvalue below -1e-8. The Supplemental Material defines the physical scaling and the scope of the controls. Numerical consistency does not establish device-specific antenna calibration, mode profiles, anisotropy or heating. See VERIFICATION.md for the executed checks and their limits.

## Separate repository upload

Upload Part_I_AU13204_Code_v8.zip as this paper's software record at https://zenodo.org. Select Software and use the title "Code for Cross-drive-engineered Kerr multistability in multimagnon cavity magnomechanics". Enter Kashif Ammar Yasir and Wu-Ming Liu as creators, and 8.0.0 as the version. Publish with public file access and cite that record's version-specific DOI in this paper. Use the other paper's separate ZIP for its separate record. Replace the pending DOI and pending-deposit wording in the corresponding manuscript and response after publication.

The archive contains source and supporting illustration assets, not precomputed numerical datasets or submission correspondence. The MIT license applies to source code. The author-provided illustration retains its provenance and existing rights. CITATION.cff provides citation metadata; insert the actual software DOI when available. No public deposit is represented as having been completed by preparing this archive.

Official upload guidance: https://help.zenodo.org/docs/deposit/create-new-upload/
