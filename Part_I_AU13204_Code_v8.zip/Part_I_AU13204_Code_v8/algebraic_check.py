"""Independent rational-polynomial elimination check for isolated operating points.
Rounded coefficients are rationalized to 12 decimal places; recovered roots are
refined and tested against the unrounded mean-field equations. Not interval
certification of the original floating-point inputs.
"""
import sympy as s
import numpy as np
from scipy.optimize import root
from model import *
def eliminate(p,digits=12,residual_tol=1e-8,dedup_tol=1e-6):
 if np.linalg.norm(drives(p))<1e-14:return [np.zeros(2)],0
 x,y=s.symbols('x y',real=True)
 def R(v):return s.Rational(str(round(float(v),digits)))
 def C(z):return R(np.real(z))+s.I*R(np.imag(z))
 B=coeff(p);dc=p['kc']+1j*p['dc'];j=C(p['gm']*p['gn']/dc);a=drives(p)
 am=C(p['rm']+p['gm']**2/dc+1j*p['dm'])+s.I*(R(B[0,0])*x+R(B[0,1])*y)
 an=C(p['rn']+p['gn']**2/dc+1j*p['dn'])+s.I*(R(B[1,0])*x+R(B[1,1])*y)
 D=s.expand(am*an-j*j);nm=C(a[0])*an-j*C(a[1]);nn=C(a[1])*am-j*C(a[0])
 def sq(z):return s.expand(z*s.conjugate(z))
 f=s.Poly(x*sq(D)-sq(nm),x,y);h=s.Poly(x*sq(nn)-y*sq(nm),x,y)
 res=s.Poly(s.resultant(f.as_expr(),h.as_expr(),y),x)
 fac=s.factor_list(res)[1];found=[]
 for pol,mult in fac:
  for (lo,hi),_ in s.polys.polytools.intervals(pol,eps=s.Rational(1,10**10)):
   xx=float((lo+hi)/2)
   if xx<0:continue
   hy=s.Poly(h.as_expr().subs(x,R(xx)),y)
   for yy in np.roots([float(v) for v in hy.all_coeffs()]):
    if abs(yy.imag)>1e-5 or yy.real<0:continue
    v=root(lambda n:residual(n,p),[xx,yy.real],tol=1e-11).x
    if min(v)>=0 and np.linalg.norm(residual(v,p))<residual_tol and np.max(abs(rhs(reconstruct(v,p),p)))<residual_tol and all(np.linalg.norm((v-t)/(1+v))>dedup_tol for t in found):found.append(v)
 return sorted(found,key=lambda v:tuple(v)),res.degree()
if __name__=='__main__':
 import json,time
 out=[]
 for k,xi in [(0,.8),(2,0),(2,.8)]:
  p=parameters(1,True);p.update(K=k,xi=xi);t=__import__('time').time();rr,d=eliminate(p);print(k,xi,len(rr),d,'seconds',__import__('time').time()-t,flush=True);out.append(dict(K=k,xi=xi,roots=[list(v) for v in rr],degree=d))
 open('algebraic_validation.json','w').write(json.dumps(out,indent=2))
