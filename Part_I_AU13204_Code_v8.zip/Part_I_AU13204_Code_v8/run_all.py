"""Reproduce the calculations and figures for Part 1."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

PART = 1

def main():
    parser = argparse.ArgumentParser(description="Reproduce Part 1 from source.")
    parser.add_argument('--out', default='output', help='Output directory')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    destination = Path(args.out).expanduser().resolve()
    destination.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ)
    environment.pop('REUSE_GENERATED', None)
    for script in ['figures.py', 'validate.py', 'controls.py',
                   'physical_checks.py', 'submission_checks.py', 'schematic.py']:
        command = [sys.executable, str(base / script), '--part', str(PART),
                   '--out', str(destination)]
        if script == 'figures.py':
            command += ['--quality', 'final']
        subprocess.run(command, check=True, cwd=base, env=environment)
    print(f'Completed Part {PART}: {destination}')

if __name__ == '__main__':
    main()
