"""Independent tolerance, overlap, extra-mode and spectral-grid controls.
No device calibration or continuum completeness claim is implied.
"""
import argparse,json
from pathlib import Path
import numpy as np
from scipy.optimize import root
from scipy.spatial import cKDTree
from model import *
from algebraic_check import eliminate
from validate import susceptibility

def classify(rr,p):
 margins=[float(max(np.linalg.eigvals(jacobian(reconstruct(n,p),p)).real)) for n in rr]
 return dict(roots=len(rr),stable=sum(x<-1e-8 for x in margins),unstable=sum(x>1e-8 for x in margins),
             max_residual=float(max(max(abs(rhs(reconstruct(n,p),p))) for n in rr)),margins=margins)

def extra(u,p,e,w):
 f=np.r_[rhs(u[:8],p), w*u[9]-.01*w*u[8],-w*u[8]-.01*w*u[9]]
 J=np.zeros((10,10));J[:8,:8]=jacobian(u[:8],p);J[8:,8:]=[[-.01*w,w],[-w,-.01*w]]
 for i,g in [(2,e*p['gmb']),(4,e*p['gnb'])]:
  x,y=u[i:i+2];q=u[8];f[i]+=g*q*y;f[i+1]-=g*q*x;f[9]-=g*(x*x+y*y)
  J[i,i+1]+=g*q;J[i+1,i]-=g*q;J[i,8]+=g*y;J[i+1,8]-=g*x;J[9,i]-=2*g*x;J[9,i+1]-=2*g*y
 return f,J

def run(part,out):
 out.mkdir(parents=True,exist_ok=True);report={}
 if part==1:
  p=parameters(1,True);tests=[]
  settings=[dict(p,K=k,xi=x) for k,x in [(0,.8),(2,0),(2,.8)]]
  settings += [dict(parameters(1),K=.02,drive=2),
               dict(parameters(1),gmb=.072,gnb=.060,drive=2),
               dict(parameters(1),gmb=.072,gnb=.060,drive=3)]
  for q in settings:
   reference,_=eliminate(q);rows=[]
   for digits,tol,dedup in [(10,1e-8,1e-5),(12,1e-10,1e-7),(14,1e-9,1e-8)]:
    rr,_=eliminate(q,digits,tol,dedup);c=classify(rr,q)
    c.update(digits=digits,residual_tol=tol,dedup_tol=dedup,
      max_population_difference=float(max(min(np.max(abs(a-b)) for b in reference) for a in rr)))
    assert len(rr)==len(reference);rows.append(c)
   tests.append(dict(parameters=q,tests=rows))
  report['tolerances']=tests
  ant=[]
  for key,values in [('bm',[.2375,.2625]),('bn',[.19,.21]),('phase_m',[.15,.25]),('phase_n',[-.20,-.10])]:
   for v in values:
    q=dict(p,**{key:v});rr,_=eliminate(q);ant.append(dict(parameter=key,value=v,**classify(rr,q)))
  report['antenna']=ant
  rr,_=eliminate(p);records=[]
  for ratio in [.5,1,2]:
   for end in [.05,.10]:
    solutions=[];residuals=[]
    for n in rr:
     u=np.r_[reconstruct(n,p),0,0]
     for e in np.linspace(0,end,51):
      sol=root(lambda v:extra(v,p,e,ratio*p['omega'])[0],u,jac=lambda v:extra(v,p,e,ratio*p['omega'])[1],tol=1e-11)
      u=sol.x;err=max(abs(extra(u,p,e,ratio*p['omega'])[0]));assert err<1e-8;residuals.append(float(err))
     if all(np.linalg.norm(u-v)>1e-6 for v in solutions):solutions.append(u)
    margins=[float(max(np.linalg.eigvals(extra(u,p,end,ratio*p['omega'])[1]).real)) for u in solutions]
    records.append(dict(frequency_ratio=ratio,e=end,continued_roots=len(solutions),stable=sum(v<-1e-8 for v in margins),unstable=sum(v>1e-8 for v in margins),max_residual=max(residuals)))
  report['additional_mechanical_mode']=records
  records=[]
  for key,v in [('K',.02),('zeta',.8),('xi',1.2),('gm',.6)]:
   q=parameters(1)
   if key=='zeta':q.update(gmb=.09*v,gnb=.075*v)
   else:q[key]=v
   clouds={n:branch(q,nx=n,xmax=250,ymax=900) for n in [2500,5000,10000]}
   norm=np.array([6,250,900]);ref=clouds[10000][:,:3]/norm;rows=[]
   for n in [2500,5000]:
    pts=clouds[n][:,:3]/norm;ds=np.r_[cKDTree(ref).query(pts)[0],cKDTree(pts).query(ref)[0]]
    rows.append(dict(nx=n,percentile95=float(np.quantile(ds,.95)),maximum=float(max(ds))))
   extended=branch(q,nx=20000,xmax=500,ymax=1800)
   records.append(dict(parameter=key,value=v,comparisons=rows,expanded_bound_outside_count=int(sum((extended[:,1]>250)|(extended[:,2]>900))),
                       max_residual=float(max(max(a[:,5]) for a in clouds.values()))))
  report['branch_sampling']=records
 else:
  p=parameters(2);records=[]
  for key,vals in [('K',[0,2,4,6,9,12]),('xi',[0,1,3,4,6,8])]:
   for v in vals:
    q=dict(p,**{key:v});rr,_=eliminate(q);c=classify(rr,q)
    stable=[reconstruct(n,q) for n in rr if max(np.linalg.eigvals(jacobian(reconstruct(n,q),q)).real)<-1e-8]
    error=max(abs(response(u,q,d)[0]-susceptibility(u,q,d)) for u in stable for d in np.linspace(-2,3,1001))
    records.append(dict(parameter=key,value=v,response_error=float(error),**c))
  report['spectral_checks']=records
  q=dict(p,ex=.9,rm=.008,rn=.008,damp=.003,damp_n=.003,xi=1.5,K=6,phase_m=np.pi,phase_n=-np.pi,gm=.45*np.sqrt(.5+.78))
  u=stationary(q);records=[]
  for n,span in [(2001,.02),(4001,.02),(4001,.04)]:
   ds=np.linspace(1.95-span,1.95+span,n);z=np.array([response(u,q,d) for d in ds]);weight=np.exp(-.5*((ds-1.95)/.001)**2)
   T=abs(z[:,0])**2;energy=np.trapezoid(weight*T,ds)/np.trapezoid(weight,ds)
   centroid=np.trapezoid(weight*T*z[:,1].real,ds)/np.trapezoid(weight*T,ds)
   records.append(dict(points=n,half_span=span,energy=float(energy),centroid_delay=float(centroid)))
  report['pulse_moment_grid']=records
 (out/'submission_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--part',type=int,required=True);a.add_argument('--out',required=True);x=a.parse_args();run(x.part,Path(x.out))
