"""Dimensional round trip and controlled omitted-coupling tests (not device calibration)."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import root
from model import parameters,drives,rhs,jacobian,stationary,response,reconstruct
from algebraic_check import eliminate

def matrix(p,e=0.):
 if p['part']==1:return np.array([[p['gmb']],[p['gnb']]])
 return np.array([[p['gmb'],e*p['gmb']],[e*p['gnb'],p['gnb']]])

def general(u,p,e=0.,exchange=0.,kn=0.):
 out=rhs(u,p).copy();J=jacobian(u,p).copy();z=u[2:6:2]+1j*u[3:6:2];G=matrix(p,e)-matrix(p,0)
 for j in range(2):
  i=2+2*j
  for k in range(G.shape[1]):
   h=6+2*k;g=G[j,k];x,y=u[i:i+2];q=u[h]
   out[i]+=g*q*y;out[i+1]-=g*q*x;out[h+1]-=g*(x*x+y*y)
   J[i,i+1]+=g*q;J[i+1,i]-=g*q;J[i,h]+=g*y;J[i+1,h]-=g*x
   J[h+1,i]-=2*g*x;J[h+1,i+1]-=2*g*y
 out[2:4]+=exchange*np.array([u[5],-u[4]]);out[4:6]+=exchange*np.array([u[3],-u[2]])
 J[2:4,4:6]+=exchange*np.array([[0,1],[-1,0]]);J[4:6,2:4]+=exchange*np.array([[0,1],[-1,0]])
 x,y=u[4:6];d=2*kn*(x*x+y*y);out[4]+=d*y;out[5]-=d*x
 J[4:6,4:6]+=np.array([[4*kn*x*y,d+4*kn*y*y],[-d-4*kn*x*x,-4*kn*x*y]])
 return out,J

def transfer(J,p,ds):
 b=np.zeros(len(J),complex);b[0]=np.sqrt(2*p['ex'])/2;b[1]=-1j*np.sqrt(2*p['ex'])/2
 a=np.zeros(len(J),complex);a[0]=1;a[1]=1j
 return np.array([1-np.sqrt(2*p['ex'])*a@np.linalg.solve(-1j*d*np.eye(len(J))-J,b) for d in ds])

def dimensional_rhs(U,p,ref,N0):
 # Independently form dimensional equations in radians/s and physical occupations.
 z=U[:6:2]+1j*U[1:6:2];c,m,n=z;g=np.array([p['gmb'],p['gnb']])*ref/np.sqrt(N0)
 q=np.repeat(U[6],2) if p['part']==1 else U[[6,8]]
 dm=np.array([p['dm'],p['dn']])*ref+g*q+2*np.array([p['K'],p['Kn']])*ref/N0*abs(z[1:])**2
 dz=np.r_[-ref*(p['kc']+1j*p['dc'])*c-1j*ref*(p['gm']*m+p['gn']*n),-(ref*np.array([p['rm'],p['rn']])+1j*dm)*z[1:]-1j*ref*np.array([p['gm'],p['gn']])*c+ref*np.sqrt(N0)*drives(p)]
 out=list(np.column_stack([dz.real,dz.imag]).ravel())
 for k in range(1 if p['part']==1 else 2):
  w=ref*(p['omega'] if k==0 else p['omega_n']);d=ref*(p['damp'] if k==0 else p['damp_n']);q,v=U[6+2*k:8+2*k]
  f=g@abs(z[1:])**2 if p['part']==1 else g[k]*abs(z[k+1])**2
  out.extend([w*v-(d*q/2 if p['mech']=='lindblad' else 0),-w*q-(d/2 if p['mech']=='lindblad' else d)*v-f])
 return np.array(out)

def run(part,out):
 out.mkdir(exist_ok=True,parents=True);report={};ref=2*np.pi*1e6;N0=1e12
 ps=[parameters(1),parameters(1,True)] if part==1 else [parameters(2),dict(parameters(2),ex=.9,rm=.008,rn=.008,damp=.003,damp_n=.003,xi=1.5,K=.5,phase_m=np.pi,phase_n=-np.pi)]
 errors=[]
 for p in ps:
  n=8 if part==1 else 10;u=np.linspace(-.73,1.13,n)
  f=rhs(u,p);fphys=dimensional_rhs(u*np.sqrt(N0),p,ref,N0)/(ref*np.sqrt(N0))
  errors.append(float(max(abs(f-fphys))/(1+max(abs(f)))))
 report['reference_Hz']=1e6;report['N0']=N0;report['dimensional_relative_errors']=errors;assert max(errors)<1e-12
 report['target_sets']=ps;records=[]
 if part==2:
  import matplotlib.pyplot as plt
  from figures import save,panel,COL
  fig,axs=plt.subplots(1,2,figsize=(11,3.8));ds=np.linspace(-1,2,3001)
  for ax,(label,p),letter in zip(axs,[('Spectral baseline',ps[0]),('Pulse operating point',dict(ps[1],K=6,gm=.45*np.sqrt(.5+.78)))],'ab'):
   u0=stationary(p);base=transfer(jacobian(u0,p),p,ds)
   assert max(abs(base-np.array([response(u0,p,d)[0] for d in ds])))<1e-11
   for ci,(name,e,j,kn) in enumerate([('Reference',0,0,0),('Cross strain +5%',.05,0,0),('Cross strain -5%',-.05,0,0),('Cross strain +10%',.1,0,0),('Second Kerr 0.02',0,0,.02),('Direct exchange 0.02',0,.02,0)]):
    u=u0.copy()
    for t in np.linspace(0,1,51):
     sol=root(lambda x:general(x,p,t*e,t*j,t*kn)[0],u,jac=lambda x:general(x,p,t*e,t*j,t*kn)[1],tol=1e-11)
     if max(abs(general(sol.x,p,t*e,t*j,t*kn)[0]))>1e-8:raise RuntimeError(name+' continuation failed')
     u=sol.x
    f,J=general(u,p,e,j,kn);mar=float(max(np.linalg.eigvals(J).real));z=transfer(J,p,ds)
    records.append(dict(operating_point=label,case=name,e=e,exchange=j,Kn=kn,margin=mar,residual=float(max(abs(f))),maximum_intensity_difference=float(max(abs(abs(z)**2-abs(base)**2)))))
    ax.plot(ds,abs(z)**2 if mar<-1e-8 else np.full(len(ds),np.nan),c=COL[ci],label=name)
   ax.set(xlabel=r'$\delta/\kappa_c$',ylabel=r'$|t_p|^2$',title=label);panel(ax,letter);ax.legend()
  save(fig,out,'Validation3')
 else:
  p=parameters(1,True);rr,_=eliminate(p)
  for j in [-.02,-.01,.01,.02]:
   solutions=[]
   for r in rr:
    u=reconstruct(r,p)
    for t in np.linspace(0,1,51):
     sol=root(lambda x:general(x,p,exchange=t*j)[0],u,jac=lambda x:general(x,p,exchange=t*j)[1],tol=1e-11);u=sol.x
     if max(abs(general(u,p,exchange=t*j)[0]))>1e-8:break
    f,J=general(u,p,exchange=j)
    if max(abs(f))<1e-8 and all(np.linalg.norm(u-v)>1e-6 for v in solutions):solutions.append(u)
   margins=[float(max(np.linalg.eigvals(general(u,p,exchange=j)[1]).real)) for u in solutions]
   records.append(dict(exchange=j,continued_distinct_roots=len(solutions),continued_stable=sum(v<-1e-8 for v in margins),margins=margins))
 report['omitted_coupling_controls']=records
 (out/'physical_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--part',required=True,type=int);a.add_argument('--out',required=True);r=a.parse_args();run(r.part,Path(r.out))
