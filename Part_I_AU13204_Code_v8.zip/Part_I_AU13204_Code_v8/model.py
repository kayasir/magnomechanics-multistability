"""Canonical mean-field model; dimensionless rates, normalized amplitudes.
Part I uses mechanical Lindblad amplitude damping gamma_b/2 (paper equations).
Part II uses Brownian q,p damping (supplied spectral notebooks).
No random sampling or fitted figure data are used.
"""
import numpy as np
from scipy.optimize import root
from numpy.polynomial import polynomial as poly

def parameters(part=1,landscape=False):
 if part==1:
  p=dict(part=1,kc=1.,ex=.5,dm=-.8,dn=.8,dc=1.,gm=.55,gn=.22,rm=.05,rn=.05,K=.015,Kn=0.,xi=.7,omega=1.,damp=.01,gmb=.09,gnb=.075,drive=1.,phase_m=.2,phase_n=-.15,bm=.25,bn=.20,mech='lindblad')
  if landscape:p.update(kc=.5,rm=.38354142045525264/2,rn=.15945453459093106/2,dc=1.911332617282521,dm=-1.6,dn=.65,omega=2.0428633234228957,damp=.21861109237335571,gm=.9514787104244576,gn=.1194719605891258,gmb=-.43886704338353333,gnb=-.6203334875956505,K=2.,drive=.43,xi=.8)
 else:p=dict(part=2,kc=1.,ex=.5,dc=0.,dm=.55,dn=1.2,gm=.45,gn=.45,rm=.03,rn=.03,K=1.,Kn=0.,xi=.25,omega=.55,omega_n=1.2,damp=.01,damp_n=.01,gmb=.35,gnb=.35,drive=.12,phase_m=0.,phase_n=0.,bm=1.,bn=1.,mech='brownian')
 return p

def drives(p):
 if 'drive_override' in p:return np.asarray(p['drive_override'],complex)
 a=np.array([1-p['xi']*p['bm']*np.exp(1j*p['phase_m']),p['xi']*p['bn']*np.exp(1j*p['phase_n'])-1])
 if p.get('matched_norm') is not None:a*=np.sqrt(p['matched_norm']/np.vdot(a,a).real)
 return a*p['drive']

def feedback(p):
 w=p['omega'];d=p['damp']/2 if p['mech']=='lindblad' else 0
 if p['part']==1:
  g=np.array([p['gmb'],p['gnb']]);return -np.outer(g,g)*w/(w*w+d*d)
 return -np.diag([p['gmb']**2/w,p['gnb']**2/p['omega_n']])

def coeff(p):
 B=feedback(p).copy();B[0,0]+=2*p['K'];B[1,1]+=2*p['Kn'];return B

def reconstruct(n,p):
 de=np.array([p['dm'],p['dn']])+coeff(p)@n
 A=np.array([[p['kc']+1j*p['dc'],1j*p['gm'],1j*p['gn']],[1j*p['gm'],p['rm']+1j*de[0],0],[1j*p['gn'],0,p['rn']+1j*de[1]]])
 z=np.linalg.solve(A,np.r_[0,drives(p)])
 u=list(np.column_stack([z.real,z.imag]).ravel())
 if p['part']==1:
  force=np.dot([p['gmb'],p['gnb']],n);d=p['damp']/2 if p['mech']=='lindblad' else 0
  q=-force*p['omega']/(p['omega']**2+d*d);v=d*q/p['omega'];u.extend([q,v])
 else:
  u.extend([-p['gmb']*n[0]/p['omega'],0,-p['gnb']*n[1]/p['omega_n'],0])
 return np.array(u)

def rhs(u,p):
 z=u[:6:2]+1j*u[1:6:2];c,m,n=z;g=np.array([p['gmb'],p['gnb']]);pop=abs(z[1:])**2
 q=np.repeat(u[6],2) if p['part']==1 else u[[6,8]]
 de=np.array([p['dm'],p['dn']])+g*q+2*np.array([p['K'],p['Kn']])*pop
 dz=np.r_[-(p['kc']+1j*p['dc'])*c-1j*(p['gm']*m+p['gn']*n),-(np.array([p['rm'],p['rn']])+1j*de)*z[1:]-1j*np.array([p['gm'],p['gn']])*c+drives(p)]
 out=list(np.column_stack([dz.real,dz.imag]).ravel())
 for k in range(1 if p['part']==1 else 2):
  w=p['omega'] if k==0 else p['omega_n'];d=p['damp'] if k==0 else p['damp_n'];force=g@pop if p['part']==1 else g[k]*pop[k];q,v=u[6+2*k:8+2*k]
  out.extend([w*v-(d/2*q if p['mech']=='lindblad' else 0),-w*q-(d/2 if p['mech']=='lindblad' else d)*v-force])
 return np.array(out)

def jacobian(u,p):
 J=np.zeros((len(u),len(u)));J[:2,:2]=[[-p['kc'],p['dc']],[-p['dc'],-p['kc']]]
 for k,(g,r,K,delta,gb) in enumerate([(p['gm'],p['rm'],p['K'],p['dm'],p['gmb']),(p['gn'],p['rn'],p['Kn'],p['dn'],p['gnb'])]):
  i=2+2*k;h=6 if p['part']==1 else 6+2*k;x,y=u[i:i+2];de=delta+gb*u[h]+2*K*(x*x+y*y)
  J[:2,i:i+2]=[[0,g],[-g,0]];J[i:i+2,:2]=[[0,g],[-g,0]]
  J[i:i+2,i:i+2]=[[-r+4*K*x*y,de+4*K*y*y],[-de-4*K*x*x,-r-4*K*x*y]]
  J[i:i+2,h]=[gb*y,-gb*x];J[h+1,i:i+2]=[-2*gb*x,-2*gb*y]
 for k in range(1 if p['part']==1 else 2):
  h=6+2*k;w=p['omega'] if k==0 else p['omega_n'];d=p['damp'] if k==0 else p['damp_n']
  J[h:h+2,h:h+2]=[[-d/2,w],[-w,-d/2]] if p['mech']=='lindblad' else [[0,w],[-w,-d]]
 return J

def residual(n,p):
 u=reconstruct(n,p);z=u[2:6:2]+1j*u[3:6:2];return (n-abs(z)**2)/(1+np.abs(n))

def roots(p,bounds=(200,500),seeds=25,extra=()):
 found=[]
 xs=np.unique(np.r_[np.linspace(0,bounds[0],seeds),np.geomspace(1e-7,bounds[0],seeds)])
 ys=np.unique(np.r_[np.linspace(0,bounds[1],seeds),np.geomspace(1e-7,bounds[1],seeds)])
 for s in list(extra)+[(x,y) for x in xs for y in ys]:
  rr=root(lambda n:residual(n,p),s,tol=1e-10);v=rr.x
  if np.all(v>=-1e-9) and np.linalg.norm(residual(v,p))<1e-8 and np.all(v<=np.array(bounds)*1.0001) and all(np.linalg.norm((v-t)/(1+v))>1e-6 for t in found):found.append(np.maximum(v,0))
 return sorted(found,key=lambda x:tuple(x))

def branch(p,nx=3000,xmax=200,ymax=700,omax=6):
 """All positive roots of cubic branch relation at each sampled n_m.
 Not a proof of global branch completeness; bounds/convergence must be checked.
 """
 a=drives(dict(p,drive=1.));dc=p['kc']+1j*p['dc'];g=p['gm']*p['gn']/dc;B=coeff(p);rows=[]
 def sq(z):return poly.polymul(z,np.conj(z)).real
 for x in np.r_[0,np.geomspace(1e-8,.01,max(30,nx//20)),np.linspace(.01,xmax,nx)]:
  am=np.array([p['rm']+p['gm']**2/dc+1j*(p['dm']+B[0,0]*x),1j*B[0,1]])
  an=np.array([p['rn']+p['gn']**2/dc+1j*(p['dn']+B[1,0]*x),1j*B[1,1]])
  nm=a[0]*an-np.array([g*a[1],0]);nn=a[1]*am-np.array([g*a[0],0]);h=poly.polysub(x*sq(nn),np.r_[0,sq(nm)])
  for y in poly.polyroots(h):
   if abs(y.imag)>1e-7*(1+abs(y.real)) or y.real<0 or y.real>ymax:continue
   y=y.real;den=poly.polyval(y,poly.polysub(poly.polymul(am,an),[g*g]));N=poly.polyval(y,nm)
   if abs(N)<1e-16:continue
   o=np.sqrt(x)*abs(den/N)
   if not 0<=o<=omax:continue
   pp=dict(p,drive=o);u=reconstruct([x,y],pp);err=np.max(abs(rhs(u,pp)))
   if err>1e-7:continue
   eig=np.linalg.eigvals(jacobian(u,pp));margin=max(eig.real)
   rows.append([o,x,y,u[0]**2+u[1]**2,margin,err])
 return np.array(rows)

def response(u,p,delta):
 J=jacobian(u,p).astype(complex);I=np.eye(len(u));v=np.zeros(len(u),complex);v[0]=np.sqrt(2*p['ex'])/2;v[1]=-1j*v[0]
 A=-1j*delta*I-J;sol=np.linalg.solve(A,v);ds=np.linalg.solve(A,1j*sol)
 t=1-np.sqrt(2*p['ex'])*(sol[0]+1j*sol[1]);dt=-np.sqrt(2*p['ex'])*(ds[0]+1j*ds[1]);return t,np.imag(dt/t) if abs(t)>1e-10 else np.nan

def stationary(p,guess=None):
 if guess is None:guess=reconstruct([0,0],p)
 r=root(lambda u:rhs(u,p),guess,jac=lambda u:jacobian(u,p),tol=1e-11)
 if np.max(abs(rhs(r.x,p)))>1e-8:
  # A fold can terminate Newton continuation. Relax the previous state using
  # the actual deterministic dynamics; never accept a large residual.
  from scipy.integrate import solve_ivp
  v=np.asarray(guess,float)
  for _ in range(6):
   sol=solve_ivp(lambda t,u:rhs(u,p),(0,2000),v,method='LSODA',rtol=2e-9,atol=1e-10)
   v=sol.y[:,-1]
   rr=root(lambda u:rhs(u,p),v,jac=lambda u:jacobian(u,p),tol=1e-11)
   if np.max(abs(rhs(rr.x,p)))<1e-8 and max(np.linalg.eigvals(jacobian(rr.x,p)).real)<-1e-8:return rr.x
  raise RuntimeError('No converged stable equilibrium after continuation/relaxation')
 return r.x
