# Verification of source version 8.0.0

The numerical source was tested on Python 3.12.14 with the pinned dependency versions. The scientific validation and control calculations were executed for release 6. The corresponding numerical modules are unchanged in releases 7 and 8. This separate package changes the launcher and paper-specific documentation; its numerical solver and plotting modules remain byte-identical to the combined version-8 source. The existing scientific checks are not described as newly rerun for this packaging step.

The separate launcher was checked to dispatch all six stages to the correct paper with final plotting quality. All Python files were syntax-checked and all local source dependencies and the corresponding Figure 1(a) asset are included. Outputs are generated locally and are not bundled as precomputed data.

Set B has (stable, unstable) root counts (2,1) at K=0, xi=0.8; (3,2) at K=2, xi=0; and (4,5) at K=2, xi=0.8. All 60 representative set-A fixed-drive counts match the preceding release. Coefficient/tolerance comparisons at six isolated settings give identical counts, population differences below 6e-14 and full-state residuals below 3.2e-12. Four branch families have 2500/5000/10000-grid comparisons and a doubled-bound test. All eight antenna perturbations preserve four stable and five unstable roots. Six weak additional-mechanical-mode endpoints retain nine continued roots, four stable and five unstable. Finite sampled coverage does not prove global completeness, and continuation does not enumerate root pairs born outside the tracked family.

The scientific supplement defines the checks and their physical limits. Device-calibrated overlap profiles are not supplied. Pixel appearance can vary with renderer and fonts.
