"""Regenerate audited figures and machine-readable records locally.
Usage: python figures.py --part 1 --out output/part1 [--quality final]
All generated numeric data are outputs, not dependencies.
"""
import argparse,json,os
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from model import *
from algebraic_check import eliminate
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif','DejaVu Serif'],'font.size':11,'axes.labelsize':15,'mathtext.fontset':'stix','legend.fontsize':8.5,'pdf.fonttype':42,'ps.fonttype':42,'savefig.dpi':320})
COL=['#0072E3','#E64125','#009E73','#BA28B0','#D98C00','#5034B8']
STYLES=['-',(0,(6,2)),(0,(3,1.5,1,1.5)),(0,(1.2,1.3)),(0,(7,2,1,2)),(0,(4,1.4))]
def save(fig,out,name):
 from matplotlib.lines import Line2D
 import subprocess
 # Presentation only: source coordinates and stability masks are unchanged.
 axes=[a for a in fig.axes if a.get_label()!='<colorbar>']
 if name!='Fig1':
  fig.set_size_inches(fig.get_figwidth()*1.02,fig.get_figheight()*.98)
  for ax in axes:
   branch='widetilde' in ax.get_xlabel() and 'Omega' in ax.get_xlabel()
   density=any(type(c).__name__=='QuadMesh' for c in ax.collections)
   ax.tick_params(direction='in',top=True,right=True,labelsize=13,width=1.15,length=4.5)
   ax.xaxis.label.set_size(15);ax.yaxis.label.set_size(15)
   for spine in ax.spines.values():spine.set_linewidth(1.65 if branch else 1.45)
   for line in ax.lines:line.set_linewidth(1.65 if line.get_gid()=='unstable_branch' else 2.1 if branch else 2.0)
   # Panel letters have a dedicated corner, separate from the legend.
   for t in ax.texts:
    if len(t.get_text())==3 and t.get_text().startswith('('):
     t.set_position((.975,.975) if branch else (.025,.975))
     t.set_ha('right' if branch else 'left');t.set_va('top')
     t.set_fontsize(15)
   leg=ax.get_legend()
   if leg:
    handles,labels=ax.get_legend_handles_labels();title=leg.get_title().get_text()
    title={'gm':r'$g_m/\kappa_c$','gn':r'$g_n/\kappa_c$','K':r'$\widetilde K$','xi':r'$\xi$'}.get(title,title)
    labels=[t.replace('gm =',r'$g_m/\kappa_{\rm ref}=$').replace('gn =',r'$g_n/\kappa_{\rm ref}=$').replace('xi =',r'$\xi=$').replace('zeta =',r'$\zeta_b=$').replace('K =',r'$\widetilde K=$') for t in labels]
    if branch:
     handles=[Line2D([],[],color=COL[j],lw=2,marker=['o','s','^','D'][j],ms=4) for j in range(len(labels))]
     ncol=1 if 'n_c' in ax.get_ylabel() else 2
     if 'n_c' in ax.get_ylabel():ax.set_ylim(0,36)
     loc='upper left';anchor=(.025,.985);fontsize=10.2
    elif density:
     ncol=1;loc='center left';anchor=(.015,.59);fontsize=10.5
    else:
     ncol=3 if len(labels)>=5 and max(map(len,labels))<12 else 2 if len(labels)>2 else 1
     loc='upper center';anchor=(.5,.99);fontsize=10.0 if max(map(len,labels))<25 else 9.
     # Reserve clear space inside the frame; no offsets or per-curve scaling.
     lo,hi=ax.get_ylim()
     if 'arg' in ax.get_ylabel():
      visible=[];xmin,xmax=ax.get_xlim()
      for ln in ax.lines:
       xx,yy=ln.get_data();xx=np.asarray(xx);yy=np.asarray(yy);ok=np.isfinite(yy)&(xx>=xmin)&(xx<=xmax)
       if np.any(ok):visible.extend(yy[ok])
      if visible:
       lo,hi=min(visible),max(visible);pad=.05*max(hi-lo,1e-6);lo-=pad;hi+=pad
     span=max(hi-lo,1e-6)
     rows=int(np.ceil(len(labels)/ncol))+(1 if title else 0)
     reserve=.12*rows+.05
     ax.set_ylim(lo,hi+span*reserve)
    leg.remove();newleg=ax.legend(handles,labels,title=title,loc=loc,bbox_to_anchor=anchor,ncol=ncol,frameon=True,facecolor='white',edgecolor='#777777',framealpha=.68,fontsize=fontsize,title_fontsize=11,columnspacing=.9,handlelength=2.1,labelspacing=.35,borderpad=.45)
    newleg.get_frame().set_linewidth(.7)
   if ax.get_title():
    # Fixed settings are identified in each caption, avoiding a second overlay.
    ax.set_title('')
  if not any(a.get_label()=='<colorbar>' for a in fig.axes):fig.tight_layout(pad=.4,h_pad=1.65,w_pad=1.5)
 pdf_tmp=out/(name+'.tmp.pdf')
 fig.savefig(pdf_tmp,bbox_inches='tight',pad_inches=.025,dpi=600)
 pdf_tmp.replace(out/(name+'.pdf'))
 fig.savefig(out/(name+'.png'),bbox_inches='tight',pad_inches=.025,dpi=160)
 eps_tmp=out/(name+'.tmp.eps')
 subprocess.run(['pdftops','-eps',str(out/(name+'.pdf')),str(eps_tmp)],check=True,stdout=subprocess.DEVNULL)
 if not eps_tmp.read_bytes().rstrip().endswith(b'%%EOF'):
  raise RuntimeError('Incomplete EPS export: '+str(eps_tmp))
 eps_tmp.replace(out/(name+'.eps'))
 plt.close(fig)
def dump(out,name,x,header):np.savetxt(out/(name+'.csv'),x,delimiter=',',header=header,comments='')
def panel(ax,letter):
 low='t_p' in ax.get_ylabel()
 ax.text(.025,.06 if low else .97,'('+letter+')',transform=ax.transAxes,va='bottom' if low else 'top',ha='left',fontweight='bold',fontsize=15,zorder=50,bbox=dict(facecolor='white',edgecolor='none',pad=1.2))
def branch_paths(a):
 """Join only nearby, same-rank roots at adjacent sampled n_m values.
 Break at a missing sample, changed root count, large displacement or stability
 change. Every coordinate remains an original solver sample; no smoothing,
 extrapolation, new roots or connection across stability changes is used.
 """
 groups=[a[a[:,1]==x][np.argsort(a[a[:,1]==x,2])] for x in np.unique(a[:,1])]
 paths=[];active=[];previous=None
 for group in groups:
  if previous is None or len(previous)!=len(group) or group[0,1]-previous[0,1]>.051:
   paths.extend(active);active=[[row] for row in group]
  else:
   for j,row in enumerate(group):
    old=previous[j]
    near=(abs(row[0]-old[0])<.15 and abs(row[2]-old[2])/(1+min(row[2],old[2]))<.08)
    same=(row[4]<-1e-8)==(old[4]<-1e-8)
    if near and same:active[j].append(row)
    else:paths.append(active[j]);active[j]=[row]
  previous=group
 paths.extend(active)
 return [np.asarray(p) for p in paths]
def p1(out,quality):
 families=[('gm',[.45,.50,.55,.60]),('gn',[.14,.18,.22,.26]),('K',[0,.01,.02,.03]),('xi',[0,.4,.8,1.2]),('zeta',[.8,1.2,1.6,2])];data={};summary={}
 nx=10000 if quality=='final' else 1400
 for key,values in families:
  for v in values:
   p=parameters();p[key]=v
   if key=='zeta':p.update(gmb=.09*v,gnb=.075*v)
   arr=np.loadtxt(out/f'branch_{key}_{v}.csv',delimiter=',',skiprows=1) if os.environ.get('REUSE_GENERATED') else branch(p,nx=nx,xmax=250,ymax=900);data[key,v]=arr;dump(out,f'branch_{key}_{v}',arr,'drive,nm,nn,nc,max_real_eigenvalue,residual');print('branch',key,v,len(arr),flush=True)
 def draw(ax,key,obs,letter,ylim):
  vals=dict(families)[key]
  for j,v in enumerate(vals):
   a=data[key,v];stable=a[:,4]<-1e-8
   for path in branch_paths(a):
    is_stable=path[0,4]<-1e-8
    if len(path)>1:
     line,=ax.plot(path[:,0],path[:,obs],color=COL[j],alpha=1 if is_stable else .80,ls='-' if is_stable else (0,(4,2.5)),solid_capstyle='round',dash_capstyle='round',zorder=3 if is_stable else 2)
     line.set_gid('stable_branch' if is_stable else 'unstable_branch')
    else:
     ax.scatter(path[:,0],path[:,obs],s=2.5 if is_stable else 1.5,c=COL[j],alpha=1 if is_stable else .8,rasterized=True,zorder=3 if is_stable else 2)
   ax.plot([],[],color=COL[j],label=f'{key} = {v:g}')
   b=a[stable][::max(1,len(a[stable])//12)];ax.scatter(b[:,0],b[:,obs],s=17,c=COL[j],marker=['o','s','^','D'][j],edgecolors='white',linewidths=.4,zorder=5)
  ax.set(xlim=(0,5.5),ylim=ylim,xlabel=r'$\widetilde\Omega$',ylabel=[None,r'$n_m$',r'$n_n$',r'$n_c$'][obs]);ax.legend(loc='upper right',framealpha=.65,markerscale=4);panel(ax,letter)
 fig,ax=plt.subplots(1,2,figsize=(10,3.9));draw(ax[0],'gm',3,'a',(0,25));draw(ax[1],'gn',3,'b',(0,25));save(fig,out,'Fig2')
 fig,ax=plt.subplots(1,3,figsize=(10.4,3.9))
 for a,k,l in zip(ax,['K','xi','zeta'],'abc'):draw(a,k,3,l,(0,25))
 fig.tight_layout();save(fig,out,'Fig3')
 fig,ax=plt.subplots(2,2,figsize=(10,7.4))
 for a,k,o,l in zip(ax.flat,['gm','gn','gm','gn'],[1,1,2,2],'abcd'):draw(a,k,o,l,(0,180 if o==1 else 350))
 fig.tight_layout();save(fig,out,'Fig4')
 fig,ax=plt.subplots(3,2,figsize=(10,10.2))
 for a,k,o,l in zip(ax.flat,['K','K','xi','xi','zeta','zeta'],[1,2]*3,'abcdef'):draw(a,k,o,l,(0,200 if o==1 else 400))
 fig.tight_layout();save(fig,out,'Fig5')
 rootdata={}
 for K,xi in [(0,.8),(2,0),(2,.8)]:
  p=parameters(1,True);p.update(K=K,xi=xi);rr,degree=eliminate(p);tab=[]
  for n in rr:
   u=reconstruct(n,p);ev=np.linalg.eigvals(jacobian(u,p));tab.append([*n,max(ev.real),max(abs(rhs(u,p))),*u,*np.column_stack([ev.real,ev.imag]).ravel()])
  tab=np.array(tab);rootdata[K,xi]=tab;dump(out,f'roots_K{K}_xi{xi}',tab,'nm,nn,margin,residual,'+','.join('state'+str(i) for i in range(8))+','+','.join('eig'+str(i)+t for i in range(8) for t in ['re','im']))
  summary[f'K{K}_xi{xi}']=dict(stable=int(sum(tab[:,2]<-1e-8)),unstable=int(sum(tab[:,2]>1e-8)),roots=tab[:,:4].tolist(),resultant_degree=degree)
 def landscape(ax,K,xi,letter):
  p=parameters(1,True);p.update(K=K,xi=xi);xx=np.linspace(0,.85,300);yy=np.linspace(0,4.6,320);X,Y=np.meshgrid(xx,yy);B=coeff(p);dc=p['kc']+1j*p['dc'];am=p['rm']+p['gm']**2/dc+1j*(p['dm']+B[0,0]*X+B[0,1]*Y);an=p['rn']+p['gn']**2/dc+1j*(p['dn']+B[1,0]*X+B[1,1]*Y);j=p['gm']*p['gn']/dc;D=am*an-j*j;a=drives(p);fm=X-abs((a[0]*an-j*a[1])/D)**2;fn=Y-abs((a[1]*am-j*a[0])/D)**2;V=np.log10(1e-14+(fm/(1+X))**2+(fn/(1+Y))**2)
  im=ax.pcolormesh(X,Y,V,cmap='YlOrBr_r',vmin=-6,vmax=2,shading='auto',rasterized=True)
  t=rootdata[K,xi];ss=t[:,2]<-1e-8;ax.scatter(t[ss,0],t[ss,1],s=90,c='#00A6FF',marker='*',edgecolors='black',linewidths=.4,label='Stable');ax.scatter(t[~ss,0],t[~ss,1],s=30,c='#EF4D32',edgecolors='black',linewidths=.4,label='Unstable')
  ax.set(xlabel=r'$n_m$',ylabel=r'$n_n$',title='');ax.text(.98,.64,rf'$\widetilde K={K:g},\;\xi={xi:g}$'+'\n'+f'Stable {sum(ss)}, unstable {sum(~ss)}',transform=ax.transAxes,fontsize=10,ha='right',va='top',bbox=dict(facecolor='white',edgecolor='none',pad=1.5));ax.legend(loc='center right',framealpha=.65);panel(ax,letter);return im
 for num,pairs in [(6,[(0,.8),(2,.8)]),(7,[(2,0),(2,.8)])]:
  fig,ax=plt.subplots(1,2,figsize=(10,4.1));fig.subplots_adjust(wspace=.25,right=.9)
  for a,pa,l in zip(ax,pairs,'ab'):im=landscape(a,*pa,l)
  fig.colorbar(im,ax=ax,label=r'$\log_{10}\mathcal{R}$',fraction=.035,pad=.03);save(fig,out,f'Fig{num}')
 # Matched norm versus original scan, compact mechanism control.
 rows=[]
 for xi in np.linspace(0,1.2,13):
  for control in [False,True]:
   p=parameters(1,True);p['xi']=float(xi)
   if control:p['matched_norm']=2.
   rr,_=eliminate(p);marg=[max(np.linalg.eigvals(jacobian(reconstruct(n,p),p)).real) for n in rr]
   rows.append([xi,int(control),np.vdot(drives(p),drives(p)).real,sum(v<-1e-8 for v in marg),sum(v>1e-8 for v in marg)])
 rows=np.array(rows);dump(out,'matched_norm_control',rows,'xi,matched_norm,drive_norm_squared,stable,unstable')
 fig,axs=plt.subplots(1,2,figsize=(9,3.6))
 for c,lab,col in [(0,'Fixed source amplitude',COL[1]),(1,'Fixed effective-drive norm',COL[2])]:
  a=rows[rows[:,1]==c];axs[0].plot(a[:,0],a[:,2],'-o',ms=3,c=col,label=lab);axs[1].plot(a[:,0],a[:,3],'-o',ms=3,c=col,label=lab)
 for a,l in zip(axs,'ab'):a.set_xlabel(r'$\xi$');panel(a,l)
 axs[0].set_ylabel(r'$|\Omega_m|^2+|\Omega_n|^2$');axs[1].set_ylabel('Stable roots at fixed drive');axs[1].set_yticks(range(1,6));axs[0].legend(fontsize=8);fig.tight_layout();save(fig,out,'Validation1')
 (out/'summary.json').write_text(json.dumps(summary,indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x)))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--part',type=int,required=True);ap.add_argument('--out',required=True);ap.add_argument('--quality',default='final',choices=['check','final']);args=ap.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
 if args.part==1:p1(out,args.quality)
 else:
  from spectra import p2
  p2(out,args.quality)
