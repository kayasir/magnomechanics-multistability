"""Targeted numerical checks. Outputs are generated locally, never inputs."""
import argparse,json
from pathlib import Path
import numpy as np
from model import *
from algebraic_check import eliminate

def susceptibility(u,p,d):
 cm=p['kc']+1j*(p['dc']-d);cp=p['kc']-1j*(p['dc']+d);jm=0j;jp=0j
 for k in range(2):
  z=u[2+2*k]+1j*u[3+2*k];gb=p['gmb'] if k==0 else p['gnb'];g=p['gm'] if k==0 else p['gn'];w=p['omega'] if k==0 else p['omega_n'];gam=p['damp'] if k==0 else p['damp_n'];r=p['rm'] if k==0 else p['rn'];K=p['K'] if k==0 else p['Kn'];de=(p['dm'] if k==0 else p['dn'])+gb*u[6+2*k]+4*K*abs(z)**2;G=gb*z;lam=2*K*z*z;chi=w/(w*w-d*d-1j*gam*d)
  am=r+1j*(de-d)-1j*chi*abs(G)**2;ap=r-1j*(de+d)+1j*chi*abs(G)**2;bm=lam-chi*G*G;bp=lam.conjugate()-chi*G.conjugate()**2;Q=am*ap-bm*bp
  cm+=g*g*ap/Q;cp+=g*g*am/Q;jm+=1j*g*g*bm/Q;jp-=1j*g*g*bp/Q
 return 1-2*p['ex']/(cm-jm*jp/cp)

def main(part,out):
 out.mkdir(parents=True,exist_ok=True);report={};p=parameters(part,part==1)
 u=stationary(p) if part==2 else reconstruct(eliminate(p)[0][0],p)
 J=jacobian(u,p);errors={}
 for h in [1e-4,1e-5,1e-6]:
  fd=np.column_stack([(rhs(u+h*np.eye(len(u))[i],p)-rhs(u-h*np.eye(len(u))[i],p))/(2*h) for i in range(len(u))]);errors[str(h)]=float(np.max(abs(fd-J)))
 report['jacobian_fd_absolute_errors']=errors
 if part==1:
  checks=[]
  for K,xi in [(0,.8),(2,0),(2,.8)]:
   q=dict(p,K=K,xi=xi);rr,degree=eliminate(q)
   for seeds,bounds in [(12,(1,5)),(24,(2,10)),(32,(5,20))]:
    rt=roots(q,bounds,seeds);checks.append(dict(K=K,xi=xi,seeds_per_axis=seeds,bounds=bounds,algebraic_count=len(rr),multiseed_count=len(rt),match=len(rr)==len(rt) and max(min(np.linalg.norm(a-b) for b in rt) for a in rr)<1e-6))
  report['landscape_independent_checks']=checks
  table=[]
  for key,values in [('K',[0,.01,.02,.03]),('zeta',[.8,1.2,1.6,2]),('xi',[0,.4,.8,1.2])]:
   for v in values:
    for O in [1.,2.,3.,4.,5.]:
     q=parameters(1);q.update(drive=O)
     if key=='zeta':q.update(gmb=.09*v,gnb=.075*v)
     else:q[key]=v
     rr,degree=eliminate(q);m=[max(np.linalg.eigvals(jacobian(reconstruct(n,q),q)).real) for n in rr];table.append(dict(parameter=key,value=v,drive=O,stable=sum(x<-1e-8 for x in m),unstable=sum(x>1e-8 for x in m),marginal=sum(abs(x)<=1e-8 for x in m)))
  report['fixed_drive_counts']=table
  # finite perturbations in second Kerr/overlap for the central nine-root case
  sens=[]
  for knob,vals in [('Kn',[0,.02,.1]),('overlap',[.95,1.,1.05])]:
   for v in vals:
    q=p.copy()
    if knob=='Kn':q['Kn']=v
    else:q['gmb']*=v;q['gnb']/=v
    rr,_=eliminate(q);ms=[max(np.linalg.eigvals(jacobian(reconstruct(n,q),q)).real) for n in rr];sens.append(dict(knob=knob,value=v,stable=sum(x<-1e-8 for x in ms),unstable=sum(x>1e-8 for x in ms)))
  report['sensitivity']=sens
 else:
  report['susceptibility_matrix_max_difference']=float(max(abs(response(u,p,d)[0]-susceptibility(u,p,d)) for d in np.linspace(-2,3,401)))
  derr=[]
  for d in [.3,.6,1.1,1.8]:
   t,tau=response(u,p,d);h=1e-6;tm=response(u,p,d-h)[0];tp=response(u,p,d+h)[0];fd=np.imag((tp-tm)/(2*h)/t);derr.append(abs(fd-tau))
  report['delay_derivative_max_difference']=float(max(derr))
  rootscheck=[]
  for key,vals in [('K',[0,2,4,6,9,12]),('xi',[0,1,3,4,6,8])]:
   for v in vals:
    q=dict(p,**{key:v});rr,degree=eliminate(q) if np.linalg.norm(drives(q))>1e-14 else ([np.zeros(2)],0);mar=[max(np.linalg.eigvals(jacobian(reconstruct(n,q),q)).real) for n in rr];rootscheck.append(dict(parameter=key,value=v,root_count=len(rr),stable=sum(x<-1e-8 for x in mar),margins=mar))
  report['selected_operating_point_root_counts']=rootscheck
  # exact symmetric-drive equivalence, same branch and global phase gauge
  q=dict(p,xi=3.);u1=stationary(q);r=dict(p,xi=0,drive=-.24);u2=stationary(r,u1)
  report['symmetric_cross_drive_equivalence_error']=float(max(abs(response(u1,q,d)[0]-response(u2,r,d)[0]) for d in np.linspace(-2,3,101)))
 (out/'validation.json').write_text(json.dumps(report,indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x)));print(json.dumps(report,indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x)))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--part',type=int,required=True);ap.add_argument('--out',required=True);a=ap.parse_args();main(a.part,Path(a.out))
